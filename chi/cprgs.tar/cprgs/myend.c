#include "mpi.h"
void end( )
{
  MPI_Finalize( );

  return;
}
